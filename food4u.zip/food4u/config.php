<?php

    define('MAILHOST', "smtp.gmail.com");

    define('USERNAME', "food4uprojects@gmail.com");

    define('PASSWORD', "gtxc qalf ilfp vuba");

    define('SEND_FROM', "food4uprojects@gmail.com");

    define('SEND_FROM_NAME', "The Food4U Project");

    define('REPLY_TO', "food4uprojects@gmail.com");

    define('REPLY_TO_NAME', "The Food4U Team");

    
?>